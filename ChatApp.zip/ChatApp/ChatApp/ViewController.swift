//
//  ViewController.swift
//  ChatApp
//
//  Created by Apple on 2019/4/30.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit
import Firebase

class ViewController: UIViewController {

    @IBOutlet weak var emailTextfield:UITextField!
    @IBOutlet weak var passwordTextfield:UITextField!
    @IBOutlet weak var passwordConfirmTextfield:UITextField!
    @IBOutlet weak var registerButton:UIButton!{
        didSet{
            self.registerButton.layer.cornerRadius = self.registerButton.frame.height / 2
            self.registerButton.layer.masksToBounds = true
        }
    }
    @IBOutlet weak var deleteButton:UIButton!{
        didSet{
            self.deleteButton.layer.cornerRadius = self.deleteButton.frame.height / 2
            self.deleteButton.layer.masksToBounds = true
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func registerAccount(sender:UIButton){
        guard let email = emailTextfield.text, email != "",
        let password = passwordTextfield.text, password != "" else{
            showAlertController(title: nil, message: "請輸入電子郵件或密碼")
           return
        }
        guard passwordConfirmTextfield.text == passwordTextfield.text else{
            showAlertController(title: nil, message: "密碼兩者不相符，請重新輸入！")
            return
        }
        //註冊Firebase使用者帳號
        Auth.auth().createUser(withEmail: email, password: password) { (result, error) in
            guard error == nil else{
                self.showAlertController(title: "Registration", message: error?.localizedDescription)
                return
            }
        }
        //儲存使用者名稱
        if let changeRequest = Auth.auth().currentUser?.createProfileChangeRequest(){
            changeRequest.displayName = email
            changeRequest.commitChanges { (error) in
                if let error = error {
                    print("Failed to change the display email: \(error.localizedDescription)")
                }
            }
        }
    }
    
    @IBAction func deleteTextfieldContent(sender:UIButton){
        passwordTextfield.text = ""
        emailTextfield.text = ""
        passwordConfirmTextfield.text = ""
        
    }
    
    @IBAction func showPassword(sender:UIButton){
        passwordTextfield.isSecureTextEntry = false
    }
    
    func showAlertController(title:String?, message:String?){
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
        present(alertController, animated: true, completion: nil)
    }


}

